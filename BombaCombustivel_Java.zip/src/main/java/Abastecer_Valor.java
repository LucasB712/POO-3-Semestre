
public class Abastecer_Valor {
    public void CalcularAbastecerValor(double valor) {
        BombaCombustivel combustivel = new BombaCombustivel();
        double litros = valor / combustivel.valorLitro;
        System.out.println("Quantidade de Litros:");
        System.out.println(litros);
       combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;

    }
}