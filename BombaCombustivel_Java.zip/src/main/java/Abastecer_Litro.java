public class Abastecer_Litro {
    public void calcularAbastecerLitro(double litros) {
        BombaCombustivel combustivel = new BombaCombustivel();
        double valor_pagar = litros * combustivel.valorLitro;
        combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
         System.out.println("Valor a pagar:");
        System.out.println(valor_pagar);

    }
}