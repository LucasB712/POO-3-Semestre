

  public class Main{

     public static void main(String[] args) {
       
       java.util.Scanner scanner = new java.util.Scanner(System.in);
       try{
         BombaCombustivel bomba = new BombaCombustivel();
         while (true) {
             System.out.println(" ");
            
             System.out.println("Tipo da gasolina inicial:");
              System.out.println(bomba.tipoCombustivel);
             System.out.println("Valor inicial do litro:");
           System.out.println(bomba.valorLitro);
             System.out.println("Quantidade de gasolina da bomba:");
           System.out.println(bomba.quantidCombustivel);

            System.out.println(" ");

           System.out.println("O que você deseja fazer:");
           System.out.println("1) Abastecer por valor(Ex: R$ 50.00)");
           System.out.println("2) Abastecer por litros(Ex: 10 Litros)");
           System.out.println("3) Alterar valor do combustivel");
           System.out.println("4) Alterar tipo do combustivel(Gasolina, Etanol)");
           System.out.println("5)Alterar quantidade de combustível na bomba");

          
            
            double s = scanner.nextInt();
            if(s == 1) {
              System.out.println("Quantos Reais?");
                 s = scanner.nextDouble();
               Abastecer_Valor av = new Abastecer_Valor();
               av.CalcularAbastecerValor(s);
              
            }

             if(s == 2) {
               System.out.println("Quantos Litros?");
               s = scanner.nextDouble();
               Abastecer_Litro al = new Abastecer_Litro();
               al. calcularAbastecerLitro(s);
            }
             if(s == 3) {
               System.out.println("Qual o novo valor?");
                double valor = scanner.nextDouble();
               AlterarValorCombustivel alc = new AlterarValorCombustivel();
               alc.AlterarValor(valor);
               bomba.valorLitro = valor;
            }

             if(s == 4) {
               System.out.println("Qual o combustivel?");
                 String f = scanner.nextLine();
               AlterarCombustivel ab = new AlterarCombustivel();
               ab.AlterarTipoCombustivel(f);

            }

             if(s == 5) {
               System.out.println("Quantidade de combustivel?");
                int valor = scanner.nextInt();
               
               AlterarQuantidCombustivel aqc = new AlterarQuantidCombustivel();
                System.out.println("Alterado!");
               aqc.alterarQuantidCombustivel(valor);
            }
           

         }       


         }
       finally {
         scanner.close();
        }
     }
 }
