public class BombaCombustivel {
    String tipoCombustivel = "Gasolina";
    double valorLitro = 5.0;
    double quantidCombustivel = 400.00;
}