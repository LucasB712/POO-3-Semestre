public class AlterarQuantidCombustivel{
    public void alterarQuantidCombustivel(float valor) {
        BombaCombustivel combustivel = new BombaCombustivel();
       combustivel.quantidCombustivel = valor;
        System.out.println(valor);

    }
}