public class AlterarCombustivel{
    public void AlterarTipoCombustivel(String tipo) {
        BombaCombustivel combustivel = new BombaCombustivel();
       combustivel.tipoCombustivel = tipo;   
        System.out.println("Alterado!");
        System.out.println(tipo);

    }
}