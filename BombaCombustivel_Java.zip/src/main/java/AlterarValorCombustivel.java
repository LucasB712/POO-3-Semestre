public class AlterarValorCombustivel{
    public void AlterarValor(double valor) {
        BombaCombustivel combustivel = new BombaCombustivel();
       combustivel.valorLitro = valor;

        System.out.println("Alterado!");
        System.out.println(valor);

    }
}