import java.util.List;
import java.util.ArrayList;


public class Ensalamento {
    
    /*Ensalar */
    public void ensalar() {
        entrardados();        
    }

    public void entrardados() {
        List<String> alunos = new ArrayList<>();
        List<String> professores = new ArrayList<>();
        List<String> curso = new ArrayList<>();
        List<String> materias = new ArrayList<>();

        List<String> materiasTI = new ArrayList<>();
        List<String> professoresTI = new ArrayList<>();
        List<String> turmaTI = new ArrayList<>();

        List<String> materiasADM = new ArrayList<>();
        List<String> professoresADM = new ArrayList<>();
        List<String> turmaADM = new ArrayList<>();
        
        curso.add("ADM");
        curso.add("TI");

        

        materias.add("POO do Curso de TI");
        materias.add("Estrutura de Dados do Curso de TI");
        materias.add("BI do Curso de ADM");
        
        alunos.add("Alfredo - TI");
        alunos.add("Amélia - TI");
        alunos.add("Ana - ADM");
        alunos.add("Bruno - TI");
        alunos.add("Bentinho - ADM");
        alunos.add("Capitú - TI");

        alunos.add("Debra - TI");
        alunos.add("Ian - ADM");
        alunos.add("Iracema - TI");
        alunos.add("Joelmir - ADM");
        alunos.add("Julieta - TI");
        alunos.add("Luana - ADM");
        alunos.add("Luciana - TI");
        alunos.add("Majô - ADM");
        alunos.add("Maria - ADM");
        alunos.add("Norberto - TI");
        alunos.add("Paulo - ADM");
        alunos.add("Romeu - ADM");
        alunos.add("Wendel - TI");
        alunos.add("Zoey - TI");

        professores.add("Mia - POO de TI");
        professores.add("Saulo - Estrutura de Dados de TI");
        professores.add("Paula - BI de ADM");

        char caractered;
        char caractere;
        char caracteredi;

    for (String palavra : alunos) {
       
    for (int i = 0; i < palavra.length() - 2; i++) {
        caractere = palavra.charAt(i);
        caractered= palavra.charAt(i+1);
        caracteredi= palavra.charAt(i+2);
        if(caractere == 'T' && caractered == 'I' || caractered == 'T' && caracteredi == 'I') {
            turmaTI.add(palavra);
            break;
        }  
        if(caractere == 'A' && caractered == 'D' && caracteredi == 'M') {
            turmaADM.add(palavra);
            break;
        }  

    }
}

for (String professor : professores) {
    
for (int i = 0; i < professor.length() - 2; i++) {
    caractere = professor.charAt(i);
    caractered= professor.charAt(i+1);
    caracteredi= professor.charAt(i+2);
   
    if(caractere == 'T' && caractered == 'I' || caractered == 'T' && caracteredi == 'I') {
        professoresTI.add(professor);
        break;
    }
    if(caractere == 'A' && caractered == 'D' && caracteredi == 'M'){
        professoresADM.add(professor);
        break;
    }  
}

for (String mater : materias) {
   
for (int i = 0; i < mater.length() - 2 ; i++) {
    
    caractere = mater.charAt(i);
    caractered = mater.charAt(i+1);
    caracteredi= mater.charAt(i+2);
    
    if(caractere == 'T' && caractered == 'I' || caractered == 'T' && caracteredi == 'I') {
        materiasTI.add(mater);
        break;
    } 
    if(caractere == 'A' && caractered == 'D' && caracteredi == 'M') {
        materiasADM.add(mater);
        break;
    }  
}
}
}
entrar(turmaTI, materiasTI, professoresTI);
entrar(turmaADM, materiasADM, professoresADM);


}

    private void entrar(List<String> turma, List<String> materias, List<String> professores) {
        System.out.println("--TURMA--\n");
        for(String t : turma) {
            System.out.println(t);
        }
        System.out.println("\n");
        System.out.println("--Materias-- \n");
        for(String m : materias) {
            System.out.println(m);
        }
        System.out.println("\n");
        System.out.println("--Professores-- \n");

        for(String p : professores) {
            System.out.println(p);
        }
    }
}

