import java.util.ArrayList;
import java.util.List;


public class Curso {

    private List<Materias> materias;
    private String curso;

    public Curso(String curso) {
        this.curso = curso;
        this.materias = new ArrayList<>();
    }


    public void adicionarMaterias(Materias materia) {
        materias.add(materia);
    }

    public String getCurso() {
        return curso;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }

    public List<Materias> getMaterias() {
        return materias;
    }

}