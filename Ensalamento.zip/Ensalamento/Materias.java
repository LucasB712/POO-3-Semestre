public class Materias {
    
    private String materias;

    public String getMaterias() {
        return materias;
    }

    public Materias(String materias) {
        this.materias = materias;
    }
}
