import java.util.ArrayList;
import java.util.List;

public class Turma{
    private Professor professor;
    private List<Aluno> alunos;
    private Curso cursos;
    
    public Turma(Professor professor, Aluno aluno, Curso cursos) {
        this.professor = professor;
        this.cursos = cursos;
        this.alunos = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }   

    public Professor getProfessor() {
        return professor;
    }
    public Curso getCursos() {
        return cursos;
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }



}