public class Professor extends Pessoa {
    private Materias materias;

    public Professor(String nome, Materias materia) {
        super(nome);
        this.materias = materia;
    }   

    
}