
public class Veiculo {
    public double peso;
    public double preco;
    
    String tipo;
    
     public String getVeiculo() {
        return tipo;
    }
    
    public String setVeiculo(String tipo) {
        this.tipo = tipo;
        return tipo;
    }
    
    public void informarPreco(double preco) {
        System.out.println("O preco a ser pago é: " + preco);
    }
}
