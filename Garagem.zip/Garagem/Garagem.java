



public class Garagem {
    public int motos = 0;
    public int carros = 0;
    public int caminhonete = 0;
    public int furgao = 0;
    
    public void veiculos() {
        System.out.println("GARAGEM");
        System.out.println("motos: " + motos);
        System.out.println("carros: " + carros);
        System.out.println("caminhonetes: " + caminhonete);
        System.out.println("furgões: " + furgao);
    
        
    }
    
}


