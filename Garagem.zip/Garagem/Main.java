import java.util.Scanner;

public class Main
{   
    static Scanner scanner = new Scanner(System.in);
    static Garagem g = new Garagem();
    static Veiculo v = new Veiculo();
	static int quantid = 0;
    static int horas = 0;
	static double preco1 = 0;
	static String pega;
    
	public static void main(String[] args) {
		
	    while (true){
	    g.veiculos();
	        
		System.out.println("Estacionamento Terraço Shopping");
		System.out.println("\n");
		System.out.println("Seja muito bem vindo");
		System.out.println("\n");
		
		System.out.println("Qual carro vai entrar?"); 
		
		System.out.println("1) Moto");
		System.out.println("2) Carro");
		System.out.println("3) Caminhonete");
		System.out.println("4) Furgão");
		System.out.println("5) Sair");
		
		int entra = scanner.nextInt();
	    	    
	    if(entra == 1) {
	        System.out.println("Qual o tipo de moto? Leve, Padrão ou Pesada");
	        scanner.nextLine();
	        pega = scanner.nextLine();
	        System.out.println("Quantas horas?");
	        horas = scanner.nextInt();
	        Moto m = new Moto();
	        System.out.println(pega + " " + horas);
	        preco1 = m.calcularPrecoMoto(pega, horas);
	        System.out.println(preco1);
	        v.informarPreco(preco1);
	        g.motos += 1; 
	        
	        
	    }
	    
	    if(entra == 2) {
	        System.out.println("Qual o tipo do carro? Hatchback, Sedan ou SUV?");
	        scanner.nextLine();
	        pega = scanner.nextLine();
	        System.out.println("Quantas horas?");
	        horas = scanner.nextInt();
	        Carro c = new Carro();
	        preco1 = c.calcularPrecoCarro(pega, horas);
	        v.informarPreco(preco1);
	        g.carros += 1;
	        
	    }
	    
	    
	    if(entra == 3) {
	        System.out.println("Qual o tipo da caminhonete? Leve ou Pesada?");
	        scanner.nextLine();
	        pega = scanner.nextLine();
	        System.out.println("Quantas horas?");
	        horas = scanner.nextInt();
	        Furgao c = new Furgao();
	        preco1 = c.calcularPrecoFurgao(pega, horas);
	        v.informarPreco(preco1);
	        g.caminhonete += 1;
	        
	    }
	    
	    
	    if(entra == 4) {
	        System.out.println("Qual o tipo da caminhonete? Leve, Padrão ou Pesada?");
	        scanner.nextLine();
	        pega = scanner.nextLine();
	        System.out.println("Quantas horas?");
	        horas = scanner.nextInt();
	        Furgao f = new Furgao();
	        preco1 = f.calcularPrecoFurgao(pega, horas);
	        v.informarPreco(preco1);
	        g.furgao += 1;
	        
	    }
	    
	    if(entra == 5) {
	     System.out.println("\n");
	     System.out.println("Obrigado! Volte sempre!");
	     return;
	    }
	   
	    }
}
}