
public class Carro extends Veiculo {
    public double calcularPrecoCarro(String tipo2, int horas) { 
        double preco;
        double total = 0 ;
    
    if (tipo2.equals("Hatchback")) {
        preco = 13.00;
        total = preco * horas;
    }
    
    if (tipo2.equals("Sedan")) {
        preco = 15.00;
        total = preco * horas;
    }
    if (tipo2.equals("SUV")) {
        preco = 20.00;
        total = preco * horas;
    }
    return total;
    }
    
}