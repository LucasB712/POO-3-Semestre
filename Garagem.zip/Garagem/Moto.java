
public class Moto extends Veiculo {
    public double calcularPrecoMoto(String tipo2, int horas) { 
        double preco;
        double total = 0 ;
    
    if (tipo2.equals("Leve")) {
        preco = 2.00;
        total = preco * horas;
    }
    
    if (tipo2.equals("Padrão")) {
        preco = 4.00;
        total = preco * horas;
    }
    if (tipo2.equals("Pesada")) {
        preco = 10.00;
        total = preco * horas;
    }
    return total;
    }
    
}
