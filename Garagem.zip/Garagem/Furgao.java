
public class Furgao extends Veiculo {
    public String tipo;
    
     public String getFurgao() {
        return tipo;
    }
    
    public void setFurgao(String tipo) {
        this.tipo = tipo;
    }
    
    public double calcularPrecoFurgao(String tipo2
    , int horas) {
   
    double total = 0;
    
    if (tipo2.equals("Carregado")) {
        preco = 50.00;
        total = preco * horas;
    }
    
    if (tipo2.equals("Não carregado")) {
        preco = 25.00;
        total = preco * horas;
    }
    return total;
}
}

