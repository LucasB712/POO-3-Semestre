public class AlterarValorCombustivel{
    public void AlterarValor(double valor, int tipo) {
      if(tipo == 1) {
        BombaCombustivel combustivel = new BombaCombustivel();
       combustivel.valorLitro = valor;

        System.out.println("Alterado!");

        
        System.out.println(valor);
        
       
         
            System.out.println(" ");

               System.out.println("Tipo:");
                System.out.println(combustivel.tipoCombustivel);
               System.out.println("Valor inicial do litro:");
             System.out.println(combustivel.valorLitro);
               System.out.println("Quantidade de gasolina da bomba:");
             System.out.println(combustivel.quantidCombustivel);
      }
      if(tipo == 2) {
        BombaCombustivelGasolinaAditivada combustivel = new BombaCombustivelGasolinaAditivada();
       combustivel.valorLitro = valor;

        System.out.println("Alterado!");
        System.out.println(valor);

        System.out.println(" ");

           System.out.println("Tipo:");
            System.out.println(combustivel.tipoCombustivel);
           System.out.println("Valor inicial do litro:");
         System.out.println(combustivel.valorLitro);
           System.out.println("Quantidade de gasolina da bomba:");
         System.out.println(combustivel.quantidCombustivel);
      }
      if(tipo == 3) {
        BombaCombustivelAlcool combustivel = new BombaCombustivelAlcool();
       combustivel.valorLitro = valor;

        System.out.println("Alterado!");
        System.out.println(valor);

        System.out.println(" ");

           System.out.println("Tipo:");
            System.out.println(combustivel.tipoCombustivel);
           System.out.println("Valor inicial do litro:");
         System.out.println(combustivel.valorLitro);
           System.out.println("Quantidade de gasolina da bomba:");
         System.out.println(combustivel.quantidCombustivel);
      }
      if(tipo == 4) {
        BombaCombustivelDiesel combustivel = new BombaCombustivelDiesel();
       combustivel.valorLitro = valor;

        System.out.println("Alterado!");
        System.out.println(valor);

        System.out.println(" ");

           System.out.println("Tipo:");
            System.out.println(combustivel.tipoCombustivel);
           System.out.println("Valor inicial do litro:");
         System.out.println(combustivel.valorLitro);
           System.out.println("Quantidade de gasolina da bomba:");
         System.out.println(combustivel.quantidCombustivel);
      }
    }
}