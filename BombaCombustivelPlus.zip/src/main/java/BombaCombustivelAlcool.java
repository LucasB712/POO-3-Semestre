public class BombaCombustivelAlcool{
    String tipoCombustivel = "Alcool";
    double valorLitro = 4.3;
    double quantidCombustivel = 400.00;
}