public class Abastecer_Litro {
    public void calcularAbastecerLitro(double litros, int tipo) {

      if(tipo == 1){
        BombaCombustivel combustivel = new BombaCombustivel();
        double valor_pagar = litros * combustivel.valorLitro;
        combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
         System.out.println("Valor a pagar:");
        System.out.println(valor_pagar);
      }
      if(tipo == 2) {
        BombaCombustivelGasolinaAditivada combustivel = new BombaCombustivelGasolinaAditivada();
        double valor_pagar = litros * combustivel.valorLitro;
        combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
         System.out.println("Valor a pagar:");
        System.out.println(valor_pagar);
      }
      if(tipo == 3){
        BombaCombustivelAlcool combustivel = new BombaCombustivelAlcool();
        double valor_pagar = litros * combustivel.valorLitro;
        combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
         System.out.println("Valor a pagar:");
        System.out.println(valor_pagar);
      }
      if(tipo == 4){
        BombaCombustivelDiesel combustivel = new BombaCombustivelDiesel();
        double valor_pagar = litros * combustivel.valorLitro;
        combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
         System.out.println("Valor a pagar:");
        System.out.println(valor_pagar);
      }

      

    }
}