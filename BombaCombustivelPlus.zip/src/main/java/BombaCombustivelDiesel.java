
public class BombaCombustivelDiesel{
    String tipoCombustivel = "Diesel";
    double valorLitro = 3.95;
    double quantidCombustivel = 400.00;
}