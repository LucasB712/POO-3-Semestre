public class BombaCombustivelGasolinaAditivada{
    String tipoCombustivel = "Gasolina Aditivada";
    double valorLitro = 5.5;
    double quantidCombustivel = 400.00;
}