public class AlterarQuantidCombustivel{
    public void alterarQuantidCombustivel(double valor, int tipo) {
        if(tipo == 1){
          
               System.out.println(" ");             
        BombaCombustivel combustivel = new BombaCombustivel();
       combustivel.quantidCombustivel = valor;
          System.out.println(" ");

             System.out.println("Tipo da gasolina:");
              System.out.println(combustivel.tipoCombustivel);
             System.out.println("Valor inicial do litro:");
           System.out.println(combustivel.valorLitro);
             System.out.println("Quantidade de gasolina da bomba:");
           System.out.println(combustivel.quantidCombustivel);

           System.out.println(" ");
        System.out.println(valor);
        }
      if(tipo == 2){



          BombaCombustivelGasolinaAditivada combustivel = new BombaCombustivelGasolinaAditivada();
         combustivel.quantidCombustivel = valor;

        System.out.println(" ");

           System.out.println("Tipo da gasolina:");
            System.out.println(combustivel.tipoCombustivel);
           System.out.println("Valor inicial do litro:");
         System.out.println(combustivel.valorLitro);
           System.out.println("Quantidade de gasolina da bomba:");
         System.out.println(combustivel.quantidCombustivel);

         System.out.println(" ");
          System.out.println(valor);
        
          }
      if(tipo == 3){

       

          BombaCombustivelAlcool combustivel = new BombaCombustivelAlcool();
         combustivel.quantidCombustivel = valor;

        System.out.println(" ");

           System.out.println("Tipo da gasolina:");
            System.out.println(combustivel.tipoCombustivel);
           System.out.println("Valor inicial do litro:");
         System.out.println(combustivel.valorLitro);
           System.out.println("Quantidade de gasolina da bomba:");
         System.out.println(combustivel.quantidCombustivel);

         System.out.println(" ");
          System.out.println(valor);
          }
      if(tipo == 4){


          BombaCombustivelDiesel combustivel = new BombaCombustivelDiesel();
         combustivel.quantidCombustivel = valor;

        System.out.println(" ");

           System.out.println("Tipo da gasolina:");
            System.out.println(combustivel.tipoCombustivel);
           System.out.println("Valor inicial do litro:");
         System.out.println(combustivel.valorLitro);
           System.out.println("Quantidade de gasolina da bomba:");
         System.out.println(combustivel.quantidCombustivel);

         System.out.println(" ");
          System.out.println(valor);
          }

    }
}