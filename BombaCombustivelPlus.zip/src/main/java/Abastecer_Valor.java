
public class Abastecer_Valor {
    public void CalcularAbastecerValor(double valor, int tipo) {  
      
        if(tipo ==  1) {
          BombaCombustivel combustivel = new BombaCombustivel();
            double litros = valor / combustivel.valorLitro;
            System.out.println("Quantidade de Litros:");
            
            System.out.println(litros);
           combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
        }
      if (tipo == 2) {
        BombaCombustivelGasolinaAditivada combustivel = new BombaCombustivelGasolinaAditivada();
          double litros = valor / combustivel.valorLitro;
          System.out.println("Quantidade de Litros:");
          System.out.println(litros);
         combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;
        
      }

      if (tipo == 3) {
        BombaCombustivelAlcool combustivel = new BombaCombustivelAlcool();
          double litros = valor / combustivel.valorLitro;
          System.out.println("Quantidade de Litros:");
          System.out.println(litros);
         combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;

      }
      if (tipo == 4) {
        BombaCombustivelDiesel combustivel = new BombaCombustivelDiesel();
          double litros = valor / combustivel.valorLitro;
          System.out.println("Quantidade de Litros:");
          System.out.println(litros);
         combustivel.quantidCombustivel =  combustivel.quantidCombustivel - litros;

      }
        

    }
}