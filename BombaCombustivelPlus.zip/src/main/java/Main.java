
public class Main {

  public static void main(String[] args) {

    java.util.Scanner scanner = new java.util.Scanner(System.in);
    try {
      BombaCombustivel bomba = new BombaCombustivel();

      while (true) {
        System.out.println(" ");

        System.out.println("POSTO IPIRANGA");

        System.out.println(" ");

        System.out.println("O que você deseja fazer:");
        System.out.println("1) Abastecer por valor(Ex: R$ 50.00)");
        System.out.println("2) Abastecer por litros(Ex: 10 Litros)");
        System.out.println("3) Alterar valor do combustivel");
        System.out.println("4)Alterar quantidade de combustível na bomba");
        

        double s = scanner.nextInt();
        if (s == 1) {
          System.out.println("Quantos Reais?");
          s = scanner.nextDouble();
          System.out.println("Qual o tipo:");
          System.out.println("1)Gasolina:");
          System.out.println("2)Gasolina Aditivada:");
          System.out.println("3)Alcool");
          System.out.println("4)Diesel");
          
          scanner.nextLine();
          int g = scanner.nextInt();
  
          Abastecer_Valor av = new Abastecer_Valor();
          
          av.CalcularAbastecerValor(s, g);

        }

        if (s == 2) {
          System.out.println("Quantos Litros?");
          s = scanner.nextDouble();

          System.out.println("Qual o tipo:");
          System.out.println("1)Gasolina:");
          System.out.println("2)Gasolina Aditivada:");
          System.out.println("3)Alcool");
          System.out.println("4)Diesel");

          Abastecer_Litro al = new Abastecer_Litro();
           scanner.nextLine();
          
          int g = scanner.nextInt();
          al.calcularAbastecerLitro(s, g);
        }
        if (s == 3) {
          System.out.println("Qual o tipo:");
          System.out.println("1)Gasolina:");
          System.out.println("2)Gasolina Aditivada:");
          System.out.println("3)Alcool");
          System.out.println("4)Diesel");
          int g = scanner.nextInt();
          System.out.println("Qual o novo valor?");
          double valor = scanner.nextDouble();
          AlterarValorCombustivel alc = new AlterarValorCombustivel();
          alc.AlterarValor(valor, g);
          bomba.valorLitro = valor;
        }

   
        if (s == 4) {
          System.out.println("Qual o tipo:");
          System.out.println("1)Gasolina:");
          System.out.println("2)Gasolina Aditivada:");
          System.out.println("3)Alcool");
          System.out.println("4)Diesel");
         
          int g = scanner.nextInt();
           System.out.println("Quantidade de combustivel?");
          double valor = scanner.nextFloat();

          AlterarQuantidCombustivel aqc = new AlterarQuantidCombustivel();
        
          aqc.alterarQuantidCombustivel(valor, g);
          System.out.println("Alterado!");
        }

      }

    } finally {
      scanner.close();
    }
  }
}
